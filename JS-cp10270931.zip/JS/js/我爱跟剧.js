muban.mxone5.二级.desc = '.mute-info-items:eq(-1)&&Text;.mute-info-items:eq(-1)&&Text;.mute-info-items:eq(-2)&&Text;.video-info-items:eq(1)&&.video-info-item.video-info-actor&&Text;.video-info-items:eq(0)&&.video-info-item.video-info-actor&&Text';
var rule = Object.assign(muban.mxone5,{
title:'我爱跟剧',
host:'https://www.genmov.com',
url:'/vodshow/fyclass--------fypage---/',
searchUrl:'/vodsearch/**----------fypage---/',
headers:{
		'User-Agent':'PC_UA',
	},
});
