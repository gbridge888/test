var rule = Object.assign(muban.mxpro,{
title:'大师兄影视.',
host:'https://dsxys.com',
url:'/vodshow/fyclass--------fypage---.html',
searchUrl:'/search-**----------fypage---/',
class_parse:'.navbar-items.swiper-wrapper li;a&&title;a&&href;/(\\d+).html',
});
